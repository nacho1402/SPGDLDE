create database EuroBodas;
use EuroBodas;

Create Table Mesa
(
idMesa int(2) ,
NombreMesa Varchar(45),
PrecioMesa Double,
DescripcionMesa varchar(200),
primary Key (idMesa)
);

drop table Mesa;
desc Mesa;
Insert into Mesa(idMesa,NombreMesa,PrecioMesa,DescripcionMesa)
values
(1,"Cocteleras","70.000","Alta vestida con centro de mesa y 2 sillas."),
(2,"Rodondas","130.000","Vestida con mantel de tafetan, con servilletas, y 10 sillas tiffanny o phoenix."),
(3,"Cuadradas","130.000","Vestida con mantel de tafetan, conservilletas, y 10 sillas tiffanny o phoenix."),
(4,"Cristal","180.000","Mesa de vidrio con forro blanco e iluminacion azul, servilleta y 10 sillas tiffany o phoenix."),
(5,"Espejo","180.000","Tipo luis XV tapa en espejo con servilleta y 10 sillas tiffany o phoenix"),
(6,"Mesa De ponque","80000","mesa con mantel y camino de rosetones letras love minis, copas de los novios,
aplique del ponque con las iniciales de los novios, y letras doradas para siempre.");

create table lugar
(
idLugar int,
NombreLugar varchar(45),
Capacidad int,
DireccionLugar varchar (45),
PrecioLugar double,
primary key (idLugar)
);

drop table Lugar;
Desc Lugar;

insert into lugar(idLugar,NombreLugar,Capacidad,DireccionLugar,PrecioLugar)
values
(1,"Terraza piso 14","90","Black tower","1200000"),
(2,"Terraza piso 12","100","Macao","1200000"),
(3,"Macao pisos 9 y 10","140","Macao","800000"),
(4,"Salon piso 8","40","Macao","600000"),
(5,"Salones 6 y 13","60","Black tower","800000"),
(6,"Hacienda la cumbre","100","Lejos","1200000"),
(7,"Hacienda el refugio","250","Chia/cajica","2000000");
 
create table SonidoIluminacion
(idSonidoIluminacion int,
TipoSonidoIluminacion varchar(45),
PrecioTotal double,
primary key (idSonidoIluminacion)
);
drop table SonidoIluminacion;
desc SonidoIluminacion;

Insert Into SonidoIluminacion(idSonidoIluminacion,TipoSonidoIluminacion,PrecioTotal)
values
(1,"Estandar","650000"),
(2,"Grande","950000"),
(3,"Array","1600000"),
(4,"Ventury","250000");

Select * From SonidoIluminacion;
 
Create table Comida
(idcomida int,
NombreComida varchar(60),
DescripcionComida varchar(200),
valorPlato double,
primary key (idComida)
);
drop table comida;
desc Comida;

 alter table Comida
 add IdTipoComida int;
 
 alter table Comida
 Add constraint Fk_Comida_TipoComida
 foreign key (IdTipoComida) references TipoComida(IdTipoComida);
 
Insert into Comida(IdComida,IdTipoComida,NombreComida,DescripcionComida,ValorPlato)
values
(01,"001","Canastas de Platano","","8000"),
(02,"001","Ceviche de Camarones","","8000"),
(03,"001","Ceviche Peruano","","8000"),
(04,"002","Carne de cerdo"," ","45000"),
(05,"002","Carne de res"," ","45000"),
(06,"002","Carne de Pollo"," ","45000"),
(07,"003","tartas de Santiago"," ","5000"),
(08,"003","Cuajada con melao"," ","5000"),
(09,"003","Chesskake"," ","5000"),
(010,"004","De Bodas"," ","3000"),
(011,"004","3 Leches"," ","3000"),
(012,"004","De Chocolate"," ","3000"),
(013,"004","De milkyway"," ","3000"),
(014,"004","De semillas de amapola"," ","3000");

Create table tipoComida
(IdTipoComida int,
NombreTipoComida Varchar (45),
primary key (IdTipoComida)
);

desc TipoComida;
Insert Into TipoComida (IdTipoComida,NombreTipoComida)
values
(001,"Entrada"),
(002,"Plato fuerte"),
(003,"Postre"),
(004,"Ponque");


create table CoctelBienvenida
(idCoctelBienvenida int,
NombreCoctel Varchar(45),
DescCoctel varchar(200),
PrecioCoctel double,
primary key (idCoctelBienvenida)
);

drop table CoctelBienvenida;
desc CoctelBienvenida;

insert into CoctelBienvenida(idCoctelBienvenida,NombreCoctel,DescCoctel,PrecioCoctel)
values
(1,"Tequila Sunrise","Coctel a base de tequila con jugo de naranja, granadina y zumo de limon, adornado con rodaja de naranja y cereza","4500"),
(2,"Mojito","Coctel a base de ron blanco y triple sec mezclado con soda y macerado de limon y melao, adornado con rodaja de limon y cereza","4500"),
(3,"kamikaze ","Coctel a base de vodka y triplesec mezclado con ginger y vegetal verde o azul, adornado con rodaja de limon con cereza","4500");

select * from  CoctelBienvenida;

create table Decoracion
(idDecoracion int,
NombreDecoracion varchar(45),
DescDecoracion varchar(200),
PrecioDecoracion float,
primary key (idDecoracion)
);

drop table decoracion;
desc Decoracion;  
insert into Decoracion(idDecoracion,NombreDecoracion,descDecoracion,PrecioDecoracion)

values(1,"Pista Led"," modulo de 1mt*1mt","150000"),
(2,"Pantalla Led","de 3mts*4 mts","1780000"),
(3,"Hora loca"," show de 1 hora con antifaces, pitos, corbatas, corbatines y collares neon.","200000"),
(14,"lluvia de Sobres"," a escoger entre dorado y madera crudo","20000"),
(4,"Fotografia y Video"," 150 fotografias aprox del evento y video editado","500000"),
(5,"Bouquet","según diseño de la novia ","90000"),
(6,"Azahares"," para el novio, padres y padrino","30000"),
(7,"Invitaciones"," Se pueden escoger de 3 tipos de ","5000"),
(8,"Divan"," Se puede escoger de 2 modelo uno de $40000 y otro de $90000","40000"),
(9,"Bicicleta, jaulas, Henos, accesorios"," ","50000"),
(10,"letras Love","Letras gigantes LOVE iluminadas de 90cms de altas","70000"),
(11,"Letras Tipo Espejo","letras tipo espejo de 45 cms de alta precio por unidad","10000"),
(12,"Backing fptografico","Backing fotografico con velo y decorado con flores","80000"),
(13,"Cartas Menu","Cartas con la informacion de la entrada, plato fuerte, postre y bebidas","1100");


select * from decoracion;


create table Evento
(idEvento int,
TipoEvento varchar (45),
TematicaEvento varchar (45),
LugarEvento varchar (45),
primary key (idEvento)
);

alter table Evento 
add IdCotizacion int;

alter table Evento
Add IdCLiente int;

alter table Evento
Add IdEmpleado int;

alter table Evento
Add constraint FK_Evento_Cotizacion
foreign key (IdCotizacion) references Cotizacion(IdCotizacion);

alter table Evento
Add constraint FK_Evento_Cliente
foreign key (IdCliente) references Cliente(IdCLiente);

Alter table Evento
Add constraint Fk_Evento_Empleado
foreign key (IdEmpleado) references Empleado(IdEmpleado);

desc Evento;
insert into Evento(idEvento,TipoEvento,Tematica,Lugar)
values();

create table Logistica
(idLogistica int,
NombreLog varchar (45),
ApellidoLog varchar (45),
RolLog varchar (45),
TelefonoLog varchar (10),
E_mailLog varchar (45),
primary key (idLogistica)
);

desc Logistica;
insert into Logistica(idLogistica,Nombre,Apellido,Rol,Telefono,E_mail)
values();
create table Cargo
(
idCargo int auto_increment,
NombreCargo Varchar(45),
primary key(IdCargo)
);

drop table Cargo;
desc Cargo;

insert into Cargo(NombreCargo)
values
("Administrador"),
("Secretaria"),
("Mesero"),
("Cocinero"),
("Servicios Generales");

create table Empleado
(idEmpleado int auto_increment,
NombreEmpleado varchar(45),
ApellidoEmpleado varchar(45),
TelefonoEmpleado varchar(10),
NumDocumentoEmpleado varchar(15),
CorreoEmpleado varchar(45),
primary key (idEmpleado)
);

desc Empleado;

alter table Empleado
Add IdCargo int ;

alter table Empleado
add constraint FK_Empleado_Cargo
foreign key(IdCargo) references Cargo(IdCargo);

insert into Empleado(IdEmpleado,NombreEmpleado,ApellidoEmpleado,TelefonoEmpleado,NumDocumentoEmpleado,CorreoEmpleado,IdCargo)
values 
(001,"Fernando","Villarreal","3101190943","1000723874","fvillareal.bodaselite@gmail.com",1),
(002,),
;

create table DetalleEmpleado
(idEmpleado int,
idCotizacion int,
primary key (idEmpleado,idCotizacion)
);


create table Cliente (
IdCliente int auto_increment,
NombreCli varchar (45),
ApellidoCli varchar(45),
TelefonoCli varchar (10),
EmailCli varchar(45),
primary key (IdCliente)
);

create table TipoDocumento
(idTipoDocumento int auto_increment,
DescripcionDocu Varchar(45),
primary key (idTipoDocumento)
);


alter table TipoDocumento
Add IdCliente int;

Alter table TipoDocumento
add IdEmpleado int;

Alter table TipoDocumento
add IdProveedor int;

Alter table TipoDocumento
add constraint FK_TipoDocumento_Cliente
foreign key(IdCliente) references Cliente(idCliente);

alter table TipoDocumento
Add constraint Fk_TipoDocumento_Empleado
foreign key (IdEmpleado) references Empleado(IdEmpleado);

alter table TipoDocumento
Add Constraint FK_TipoDocumento_Proveedor
foreign key (IdProveedor) references Proveedor(Idproveedor);
 
create table DetalleEvento
(idLogistica int,
idEvento int,
primary key (idLogistica,idEvento)
);

create table DetalleDecoracion
(idDecoracion int,
idCotizacion int,
primary key (idDecoracion,idCotizacion)
);

create table DetalleCoctelBienvenida
(idCoctelBienvenida int,
idCotizacion int,
primary key (idCoctelBienvenida,idCotizacion)
);

create table DetalleComida
(idComida int,
idCotizacion int,
primary key (idComida,idCotizacion)
);


create table Cotizacion
(idCotizacion int,
FechaCotizacion date,
TipoCotizacion varchar (45),
DescCotizacion varchar (45),
PrecioFinal float,
primary key (idCotizacion)
);

alter table Cotizacion
add IdMesa int;

alter table Cotizacion
Add IdSalon int;

alter table Cotizacion
add idSonidoIluminacion int;

alter table Cotizacion 
add Idcliente int;


alter table Cotizacion
add constraint FK_Cotizacion_Salon
foreign key (Idsalon) references Salon(Idsalon);

alter table Cotizacion
Add Constraint FK_Cotizacion_Mesa
foreign key (IdMesa) references Mesa(IdMesa);

alter table Cotizacion
Add constraint FK_Cotizacion_SonidoIluminacion
foreign key (idSonidoIluminacion) references SonidoIluminacion(idSonidoIluminacion);

alter table Cotizacion 
add Constraint FK_Cotizacion_Cliente
foreign key(IdCliente) references CLiente(IdCliente); 

desc Cotizacion;
insert into Cotizacion(idCotizacion,FechaCotizacion,TipoCotizacion,DescCotizacion,PrecioFinal)
values();

select * from mesa;
select * from decoracion;